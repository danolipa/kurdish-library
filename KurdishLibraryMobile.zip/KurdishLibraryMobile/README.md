# کتێبخانەی کوردی — Mobile APK Project

ئەم پڕۆژەیە وەشانی Android ـەکی سادە و mobile-friendly ـی کتێبخانەی کوردییە. React/Node پێویست نییە بۆ build ـکردن.

## Build لەسەر Android
1. ZIP ـەکە Extract بکە.
2. AndroidIDE یان IDE ـێکی Android کە Gradle project پشتیوانی دەکات دابمەزرێنە.
3. فولدەری `KurdishLibraryMobile` بکەرەوە.
4. چاوەڕێ بکە Gradle sync تەواو ببێت.
5. `app > Tasks > build > assembleDebug` جێبەجێ بکە.
6. APK: `app/build/outputs/apk/debug/app-debug.apk`

## تایبەتمەندی
- Android 7.0+ (minSdk 24)
- کارکردنی ناوخۆیی و هەڵگرتنی کتێب بە localStorage
- گەڕان، پوختە، 4 theme، RTL و TTS
- هیچ server ـێکی تایبەت بۆ خوێندنەوەی کتێبە هەڵگیراوەکان پێویست نییە.

## تێبینی
بۆ زیادکردنی پوختەی خۆکار بە AI و گەڕانی وێب، API/backend پێویستە. ئەو بەشە لە build ـی offline ـدا دانەنراوە.
